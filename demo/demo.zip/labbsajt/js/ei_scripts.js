// JavaScript Document



// DOCUMENT READY - När DOM är laddat
$(document).ready(function() {	

	// initialer
	//var winwidth = $(window).width();
	//var winheight = $(window).height();
	//
	
	//const lightbox = GLightbox();
  

});
/////////////////////




// WINDOW LOAD - När hela sidan är laddad
$(window).load(function() {	

	// initialer
	//var winwidth = $(window).width();
	//var winheight = $(window).height();
	//
	
  
  

});
/////////////////////



// WINDOW UNLOAD - När du lämnar sidan
$(window).unload(function() {	

	
  
  

});
/////////////////////




// WINDOW RESIZE - När fönstret ändrar storlek
$(window).resize(function() {	

	// initialer
	//var winwidth = $(window).width();
	//var winheight = $(window).height();
	//
  
  

});
/////////////////////




// WINDOW SCROLL - När man scrollar sidan
$(window).scroll(function() {	

	// initialer
	//var scrollpos = $(window).scrollTop();
	//
  

});
/////////////////////



// AJAX LOAD - När allt ajaxladdat innehåll är färdigladdat
$(document).ajaxStop(function() {
	


	
});
/////////////////////




// FUNCTIONS
   

//Hypenate long words if neccesary

//Usage: ei_hypenateWord('h1,h3');

function ei_hypenateWord(elements) {
	
		$(elements).each(function (index) {
		var contlength = $(this).parent().width();
	    var words = $(this).text().split(" ");
	    
	    var tagname = $(this).prop("tagName");
	    var classes = $(this).prop("class");
	    var id = $(this).prop("id");
	
	    $this = $(this);
	    $this.empty();
	    
	    $this.parent().append('<div class="ei_hyp_testcont" style="position:absolute;opacity:0"></div>');   
	    
	    $.each(words, function (i, el) {
	        var ord = '<'+tagname+' class="'+classes+'" id="'+id+'">' + el + '</'+tagname+'>';
	           
	    $('.ei_hyp_testcont').html(ord);
	    var ordlangd = $('.ei_hyp_testcont').width();
	    
	        console.log('ord: ' + el + ' ordlängd: ' + ordlangd + ' container: ' + contlength);
	        
	        if(ordlangd > contlength) {
	        	$this.append("<span style='-webkit-hyphens: auto;-ms-hyphens: auto;hyphens: auto;'>" + el + "</span> ");
	        } else {
		       $this.append("<span>" + el + "</span> "); 
	        }
	        
	        
	    });
   
	     $('.ei_hyp_testcont').remove(); 
	     
	 });
	
}
//

//
